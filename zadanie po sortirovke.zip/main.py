def binary_search(arr, x):
  """
  Функция бинарного поиска
  """
  low = 0
  high = len(arr) - 1
  while low <= high:
      mid = (low + high) // 2
      if arr[mid] == x:
          return mid
      elif arr[mid] < x:
          low = mid + 1
      else:
          high = mid - 1
  return -1

def linear_search(arr, x):
  """
  Функция линейного поиска
  """
  for i in range(len(arr)):
      if arr[i] == x:
          return i
  return -1

def quick_sort(arr):
  """
  Функция быстрой сортировки
  """
  if len(arr) <= 1:
      return arr
  pivot = arr[len(arr) // 2]
  left = [x for x in arr if x < pivot]
  middle = [x for x in arr if x == pivot]
  right = [x for x in arr if x > pivot]
  return quick_sort(left) + middle + quick_sort(right)

# Получаем данные от пользователя
print("у нас есть 3 типа сортировки\n быстрая сортировка - 1\nбинарный поиск - 2\nлинейный поиск - 3")
a = input("Введите список чисел, разделенных пробелами(не больше десяти): ")
arr = list(map(int, a.split()))
b= str(input("выберите тип сортировки: "))
if b == "1":
    quick_sort(arr)
    print("Отсортированный список:", arr)
elif b == "2":
    search_value = int(input("Введите число для поиска: "))
    print("Индекс элемента:", binary_search(arr, search_value))
elif b == "3":
    search_value = int(input("Введите число для поиска: "))
    print("Индекс элемента:", linear_search(arr, search_value))
else:
    print("где то ты накосячил")